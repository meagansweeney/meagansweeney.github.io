// this empty JavaScript file can be filled with code later
// now it is just two comment examples in JavaScript
